//
//  ViewController.swift
//  TechApp
//
//  Created by 이한규 on 2021/09/27.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

