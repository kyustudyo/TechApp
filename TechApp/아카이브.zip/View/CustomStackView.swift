//
//  CustomText.swift
//  TechApp
//
//  Created by 이한규 on 2021/09/28.
//

import Foundation
import UIKit
class CustomStackView: UIView {
    //var myInformationVM :MyInfoViewModel?
//    {//static 공부.
//        didSet{
//        //configure()
//    }
//
//    }
//    @IBOutlet var name: UILabel!
//    @IBOutlet var field: UILabel!
//    @IBOutlet var company: UILabel!
//    @IBOutlet var contents: UITextView!

//    private func configure() {
//        name.text = myInformationVM?.name
//        field.text = myInformationVM?.field
//        company.text = myInformationVM?.company
//        //contents.text = myInformationVM?.contents
//    }


}
